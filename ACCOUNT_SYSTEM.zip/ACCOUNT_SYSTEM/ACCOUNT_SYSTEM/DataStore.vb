﻿Public Class DataStore

    ''' <summary>
    ''' 勘定科目リスト
    ''' </summary>
    ''' <returns>勘定科目リスト</returns>
    Public Property AccountSubjects

End Class
